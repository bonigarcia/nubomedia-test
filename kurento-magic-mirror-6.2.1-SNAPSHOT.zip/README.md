Kurento Java Tutorial 2 - Magic Mirror
======================

The Kurento Java Tutorial 2 - Magic Mirror shows how to build a WebRTC in loopback with faceoverlay filter application with Kurento.

Installation instructions
-------------------------

By running install.sh, the jar file containing the demo will be copied into 
_/var/lib/kurento_, and the startup script will be put in _/etc/init.d/kurento-magic-mirror_. Once the demo is installed, it can be managed as a regular service with

```
sudo service kurento-magic-mirror {start|stop|restart}
```

If you want to change the port, you can do so by editing the startup script, and setting the desired value in _APP\_PORT_.